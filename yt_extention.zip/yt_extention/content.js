function createToggleButton() {
    const button = document.createElement('button');
    button.textContent = 'Focus';
    button.id = 'focus-button';
    document.querySelector('#below').prepend(button);

    let overlays = [];

    button.addEventListener('click', () => {
        const player = document.getElementById('player');
        const rect = player.getBoundingClientRect();

        if (overlays.length === 0) {
            const top = rect.top;
            const left = rect.left;
            const width = rect.width;
            const height = rect.height;
            const right = window.innerWidth - rect.right;
            const bottom = window.innerHeight - rect.bottom;

            const topOverlay = createOverlay(0, 0, '100vw', `${top}px`);
            const bottomOverlay = createOverlay(0, `${rect.bottom}px`, '100vw', `${bottom}px`);
            const leftOverlay = createOverlay(0, `${top}px`, `${left}px`, `${height}px`);
            const rightOverlay = createOverlay(`${rect.right}px`, `${top}px`, `${right}px`, `${height}px`);

            overlays = [topOverlay, bottomOverlay, leftOverlay, rightOverlay];
            overlays.forEach(el => document.body.appendChild(el));
            document.body.classList.add('overlay-active');
            button.textContent = 'Exit';
        } else {
            overlays.forEach(el => el.remove());
            overlays = [];
            document.body.classList.remove('overlay-active');
            button.textContent = 'Focus';
        }
    });

    function createOverlay(left, top, width, height) {
        const el = document.createElement('div');
        el.className = 'yt-focus-overlay';
        el.style.left = left;
        el.style.top = top;
        el.style.width = width;
        el.style.height = height;
        return el;
    }
}

// Hide Shorts
const style = document.createElement('style');
style.textContent = `
  ytd-reel-shelf-renderer,
  ytd-reel-item-renderer,
  a[href*="/shorts"],
  ytd-reel-video-renderer {
    display: none !important;
  }
`;
document.head.appendChild(style);

// Run on normal videos
if (window.location.href.includes('/watch')) {
    const checkExist = setInterval(() => {
        const container = document.getElementById('player');
        const buttonArea = document.querySelector('#below');
        if (container && buttonArea) {
            clearInterval(checkExist);
            createToggleButton();
        }
    }, 500);
}
